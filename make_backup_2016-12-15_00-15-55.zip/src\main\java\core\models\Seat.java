package core.models;

/**
 * Created by Kévin on 2016-12-14.
 */
public class Seat {

}