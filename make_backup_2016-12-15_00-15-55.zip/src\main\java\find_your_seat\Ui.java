package find_your_seat;

import javax.swing.*;

/**
 * Created by Kévin on 2016-12-15.
 */
public class Ui extends JFrame {
    private JTextArea textArea1;
    private JButton button1;
    private JPanel panel1;

    public Ui(){
        super("Mon app");
        textArea1 = new JTextArea();
        button1 = new JButton();
        panel1 = new JPanel();
        panel1.add(textArea1);
        panel1.add(button1);
        setContentPane(panel1);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

}
