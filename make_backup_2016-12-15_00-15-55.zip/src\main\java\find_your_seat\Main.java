package find_your_seat;

/**
 * Created by Kévin on 2016-12-14.
 */
public class Main {
    public static void main(String [] args)
    {
        System.out.print("Systeme démarrer");
        Ui ui = new Ui();
    }
}
